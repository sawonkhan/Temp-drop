import express from 'express';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import multer from 'multer';
import Database from 'better-sqlite3';
import crypto from 'crypto';
import fs from 'fs';
import path from 'path';
import dns from 'dns/promises';
import net from 'net';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const STORAGE = path.join(__dirname, 'storage');
const DB_DIR = path.join(__dirname, 'db');
fs.mkdirSync(STORAGE, { recursive: true, mode: 0o700 });
fs.mkdirSync(DB_DIR, { recursive: true, mode: 0o700 });

const PORT = Number(process.env.PORT || 3000);
const MAX_FILE_SIZE = Number(process.env.MAX_FILE_SIZE || 2 * 1024 * 1024 * 1024);
const TTL_SECONDS = 60 * 60;

const db = new Database(path.join(DB_DIR, 'tempdrop.db'));
db.pragma('journal_mode = WAL');
db.exec(`CREATE TABLE IF NOT EXISTS files (
  id TEXT PRIMARY KEY,
  stored_name TEXT NOT NULL UNIQUE,
  original_name TEXT NOT NULL,
  size INTEGER NOT NULL,
  source TEXT NOT NULL,
  created_at INTEGER NOT NULL,
  expires_at INTEGER NOT NULL
)`);

const app = express();
app.disable('x-powered-by');
app.use(helmet({ crossOriginResourcePolicy: { policy: 'same-origin' } }));
app.use(express.json({ limit: '32kb' }));
app.use(express.static(path.join(__dirname, 'public')));

const apiLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 60, standardHeaders: 'draft-8', legacyHeaders: false });
app.use('/api/', apiLimiter);

const upload = multer({
  dest: STORAGE,
  limits: { fileSize: MAX_FILE_SIZE, files: 1 },
  fileFilter: (_req, _file, cb) => cb(null, true)
});

function token() { return crypto.randomBytes(18).toString('base64url'); }
function safeName(name) {
  const base = path.basename(name).replace(/[\0\r\n\\/]/g, '_').trim();
  return base.slice(0, 240) || 'download';
}
function isPrivateIp(ip) {
  if (net.isIPv4(ip)) {
    const p = ip.split('.').map(Number);
    return p[0] === 10 || p[0] === 127 || (p[0] === 169 && p[1] === 254) ||
      (p[0] === 172 && p[1] >= 16 && p[1] <= 31) ||
      (p[0] === 192 && p[1] === 168) || p[0] === 0 || p[0] >= 224;
  }
  if (net.isIPv6(ip)) {
    const x = ip.toLowerCase();
    return x === '::1' || x === '::' || x.startsWith('fc') || x.startsWith('fd') || x.startsWith('fe80:');
  }
  return true;
}
async function validateRemoteUrl(raw) {
  let u;
  try { u = new URL(raw); } catch { throw new Error('Invalid URL'); }
  if (!['http:', 'https:'].includes(u.protocol)) throw new Error('Only HTTP/HTTPS URLs are allowed');
  if (u.username || u.password) throw new Error('URL credentials are not allowed');
  const host = u.hostname.replace(/^\[|\]$/g, '').toLowerCase();
  if (host === 'localhost' || host.endsWith('.localhost') || host.endsWith('.local')) throw new Error('Private/internal hosts are blocked');
  const records = await dns.lookup(host, { all: true });
  if (!records.length || records.some(r => isPrivateIp(r.address))) throw new Error('Private/internal IP addresses are blocked');
  return u;
}

function saveMeta({ originalName, size, source }) {
  const id = token();
  const stored = crypto.randomBytes(24).toString('hex');
  const now = Math.floor(Date.now() / 1000);
  db.prepare(`INSERT INTO files(id,stored_name,original_name,size,source,created_at,expires_at) VALUES(?,?,?,?,?,?,?)`)
    .run(id, stored, safeName(originalName), size, source, now, now + TTL_SECONDS);
  return { id, stored, expiresAt: now + TTL_SECONDS };
}

function removeRow(row) {
  try { fs.rmSync(path.join(STORAGE, row.stored_name), { force: true }); } catch {}
  db.prepare('DELETE FROM files WHERE id=?').run(row.id);
}

function cleanup() {
  const now = Math.floor(Date.now() / 1000);
  const rows = db.prepare('SELECT * FROM files WHERE expires_at <= ?').all(now);
  for (const row of rows) removeRow(row);
}
setInterval(cleanup, 60_000).unref();
cleanup();

app.post('/api/upload', upload.single('file'), (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'No file uploaded' });
  try {
    const meta = saveMeta({ originalName: req.file.originalname, size: req.file.size, source: 'upload' });
    fs.renameSync(req.file.path, path.join(STORAGE, meta.stored));
    res.json({ ok: true, id: meta.id, name: safeName(req.file.originalname), size: req.file.size,
      url: `/d/${meta.id}`, expiresAt: meta.expiresAt });
  } catch (e) {
    try { fs.rmSync(req.file.path, { force: true }); } catch {}
    res.status(500).json({ error: 'Upload failed' });
  }
});

app.post('/api/from-url', async (req, res) => {
  const raw = String(req.body?.url || '').trim();
  if (!raw) return res.status(400).json({ error: 'URL is required' });
  let current;
  try { current = await validateRemoteUrl(raw); } catch (e) { return res.status(400).json({ error: e.message }); }

  const tmp = path.join(STORAGE, `.download-${crypto.randomBytes(12).toString('hex')}`);
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 5 * 60 * 1000);
  try {
    let response;
    for (let hops = 0; hops <= 5; hops++) {
      response = await fetch(current, { redirect: 'manual', signal: controller.signal, headers: { 'User-Agent': 'TempDrop/1.0' } });
      if ([301,302,303,307,308].includes(response.status)) {
        const location = response.headers.get('location');
        if (!location) throw new Error('Redirect without location');
        current = await validateRemoteUrl(new URL(location, current).href);
        continue;
      }
      break;
    }
    if (!response?.ok) throw new Error(`Remote server returned HTTP ${response?.status ?? 'unknown'}`);
    const len = Number(response.headers.get('content-length') || 0);
    if (len && len > MAX_FILE_SIZE) throw new Error('Remote file is larger than the upload limit');

    const fileStream = fs.createWriteStream(tmp, { mode: 0o600 });
    const reader = response.body.getReader();
    let size = 0;
    try {
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        size += value.byteLength;
        if (size > MAX_FILE_SIZE) throw new Error('Remote file is larger than the upload limit');
        if (!fileStream.write(Buffer.from(value))) await new Promise(r => fileStream.once('drain', r));
      }
      await new Promise((resolve, reject) => { fileStream.end(resolve); fileStream.on('error', reject); });
    } catch (e) { fileStream.destroy(); throw e; }

    let filename = current.pathname.split('/').filter(Boolean).pop() || 'download';
    try { filename = decodeURIComponent(filename); } catch {}
    const meta = saveMeta({ originalName: filename, size, source: 'url' });
    fs.renameSync(tmp, path.join(STORAGE, meta.stored));
    res.json({ ok: true, id: meta.id, name: safeName(filename), size, url: `/d/${meta.id}`, expiresAt: meta.expiresAt });
  } catch (e) {
    try { fs.rmSync(tmp, { force: true }); } catch {}
    res.status(400).json({ error: e.name === 'AbortError' ? 'Download timed out' : (e.message || 'URL download failed') });
  } finally { clearTimeout(timer); }
});

app.get('/api/file/:id', (req, res) => {
  const row = db.prepare('SELECT * FROM files WHERE id=?').get(req.params.id);
  if (!row || row.expires_at <= Math.floor(Date.now()/1000)) {
    if (row) removeRow(row);
    return res.status(404).json({ error: 'File expired or not found' });
  }
  res.json({ id: row.id, name: row.original_name, size: row.size, source: row.source, expiresAt: row.expires_at, url: `/d/${row.id}` });
});

app.get('/d/:id', (req, res) => {
  const row = db.prepare('SELECT * FROM files WHERE id=?').get(req.params.id);
  if (!row || row.expires_at <= Math.floor(Date.now()/1000)) {
    if (row) removeRow(row);
    return res.status(404).send('This file has expired or does not exist.');
  }
  const full = path.join(STORAGE, row.stored_name);
  if (!fs.existsSync(full)) return res.status(404).send('File not found.');
  res.setHeader('Content-Disposition', `attachment; filename="${row.original_name.replace(/"/g, '')}"`);
  res.setHeader('Content-Type', 'application/octet-stream');
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.sendFile(full);
});

app.use((err, _req, res, _next) => {
  if (err?.code === 'LIMIT_FILE_SIZE') return res.status(413).json({ error: 'File exceeds the upload limit' });
  res.status(500).json({ error: 'Server error' });
});

app.listen(PORT, '127.0.0.1', () => console.log(`TempDrop listening on 127.0.0.1:${PORT}`));
