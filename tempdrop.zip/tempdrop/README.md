# TempDrop

Temporary file sharing service with 1-hour expiry.

## Features
- Local file upload
- Download a file from an HTTP/HTTPS URL
- Random unguessable download URLs
- Automatic deletion after 1 hour
- SQLite metadata
- 2 GB default max file size (change MAX_FILE_SIZE)
- SSRF protection for remote URL downloads
- Rate limiting and security headers
- Files stored outside the public web root and served as `application/octet-stream`
- Uploaded files are never executed by the app

## Requirements
Ubuntu/Debian VPS, Node.js 20+ and Nginx.

## Install
```bash
sudo apt update
sudo apt install -y nginx curl build-essential
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs
sudo mkdir -p /opt/tempdrop
sudo chown -R $USER:$USER /opt/tempdrop
# copy this project into /opt/tempdrop
cd /opt/tempdrop
npm install
npm start
```

Test locally:
```bash
curl http://127.0.0.1:3000
```

## systemd
Create `/etc/systemd/system/tempdrop.service`:
```ini
[Unit]
Description=TempDrop temporary file sharing
After=network.target

[Service]
Type=simple
WorkingDirectory=/opt/tempdrop
ExecStart=/usr/bin/node /opt/tempdrop/server.js
Restart=always
RestartSec=3
Environment=NODE_ENV=production
Environment=PORT=3000
Environment=MAX_FILE_SIZE=2147483648
User=tempdrop
Group=tempdrop

[Install]
WantedBy=multi-user.target
```

Then:
```bash
sudo useradd --system --home /opt/tempdrop --shell /usr/sbin/nologin tempdrop
sudo chown -R tempdrop:tempdrop /opt/tempdrop
sudo systemctl daemon-reload
sudo systemctl enable --now tempdrop
sudo systemctl status tempdrop
```

## Nginx
Example `/etc/nginx/sites-available/tempdrop`:
```nginx
server {
    listen 80;
    server_name files.example.com;

    client_max_body_size 2G;

    location / {
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_request_buffering off;
    }
}
```

Enable:
```bash
sudo ln -s /etc/nginx/sites-available/tempdrop /etc/nginx/sites-enabled/tempdrop
sudo nginx -t && sudo systemctl reload nginx
```

Then add HTTPS with Certbot:
```bash
sudo apt install -y certbot python3-certbot-nginx
sudo certbot --nginx -d files.example.com
```

## Important security notes
The URL downloader intentionally blocks loopback, RFC1918, link-local and other private IP ranges. It also validates redirects. Keep this protection enabled because arbitrary URL fetching can otherwise create an SSRF vulnerability.

The storage directory is not exposed as a static web directory. Download requests are handled by `/d/:id`, and the server forces `application/octet-stream` plus `nosniff`.

For public deployment, consider adding authentication/admin controls, per-IP upload/download quotas, disk quota monitoring, antivirus scanning, and stronger outbound network isolation if untrusted users can submit arbitrary URLs.
